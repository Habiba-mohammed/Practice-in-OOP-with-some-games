// File name: A3_SheetPb5_20220198.cpp
// Purpose: task list and sort by pid,name,memory usage
// Author(s): Abdelaziz Ali Ahmed Ali Elarabi
// ID(s): 20220198
// Section: s3-s4
// Date: 12/10/2023

#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <string>
#include <sstream>


using namespace std;

class Process {
public:
    string name;
    string pid;
    string size_in_bits;
    string session_name;
    string session_number;

    Process(const string& _name, string _pid, string _size_in_bits, const string& _session_name, string _session_number)
            : name(_name), pid(_pid), size_in_bits(_size_in_bits), session_name(_session_name), session_number(_session_number) {}

    void display() const {
        cout << name << " " << pid << " " << session_name << " " << session_number <<" "<< size_in_bits <<endl;
    }
};

class RunningProcess {
private:
    vector<Process> processes;

public:
    string Header_1="Image Name                     PID Session Name        Session#    Mem Usage";
    string Header_2="========================= ======== ================ =========== ============";

    void add(const Process& process) {
        processes.push_back(process);
    }

    void sortProcesses(int type) {
        cout << Header_1 << "\n";
        cout << Header_2 << "\n";
        if (type == 1)
            sort(processes.begin(), processes.end(), [](const Process& a, const Process& b) { return a.name < b.name; });
        else if (type == 2)
            sort(processes.begin(), processes.end(), [](const Process& a, const Process& b) { return a.pid < b.pid; });
        else if (type == 3)
            sort(processes.begin(), processes.end(), [](const Process& a, const Process& b) { return a.size_in_bits < b.size_in_bits; });
    }

    void display() const {
        for (const auto& process : processes) {
            process.display();
        }
        cout<<endl;
        cout<<"============================================================================================================";
    }
};

void loadProcesses(RunningProcess& current_list,const string& a) {
    string s="tasklist> "+a;
    system(s.c_str());

    ifstream input(a);
    if (!input.is_open()) {
        cerr << "Error: Unable to open input.txt\n";
        return;
    }

    string line;
    getline(input, line) ;// skip the first white space
    getline(input, line) ;// skip the names
    getline(input, line) ;// skip the equals

    while (getline(input, line)) {
        string name, session_name, size_in_bits,pid_str,session_number;

        // Extract substrings based on indices
        name = line.substr(0, 25); // done
        pid_str = (line.substr(26, 8)); // done
        session_name = line.substr(35, 16); //done
        session_number = line.substr(52, 11); //done
        size_in_bits = line.substr(64, 12); //done


        //Create a new Process object and add it to the RunningProcess
        current_list.add(Process(name, pid_str, size_in_bits, session_name, session_number));
    }
}

int main() {
    RunningProcess OS;
    // Get the file name from the user
    string fileName;
    cout << "Enter the file name: ";
    cin >> fileName;

    loadProcesses(OS,fileName);

    // Get the sort type from the user
    int sortType;
    cout << "Choose a sort type:\n"
         << "1. Sort by Name\n"
         << "2. Sort by PID\n"
         << "3. Sort by Memory Usage\n"
         <<"4. No sort, print as is. "
         << "Enter the number corresponding to your choice: ";
    cin >> sortType;



    // Display processes based on the user's choice
    switch (sortType) {
        case 1:
            cout << "\nProcesses sorted by name:\n";
            OS.sortProcesses(1);
            OS.display();
            break;
        case 2:
            cout << "\nProcesses sorted by PID:\n";
            OS.sortProcesses(2);
            OS.display();
            break;
        case 3:
            cout << "\nProcesses sorted by memory usage:\n";
            OS.sortProcesses(3);
            OS.display();
            break;
        case 4:
            cout << "\nProcesses :\n";
            OS.sortProcesses(4);
            OS.display();
            break;
        default:
            cerr << "Invalid choice. Exiting...\n";
            return 1;
    }

    return 0;
}