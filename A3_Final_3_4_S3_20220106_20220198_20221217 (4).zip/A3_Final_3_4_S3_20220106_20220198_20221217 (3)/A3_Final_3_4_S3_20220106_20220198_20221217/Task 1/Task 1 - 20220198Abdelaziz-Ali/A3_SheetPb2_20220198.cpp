// File name: A3_SheetPb2_20220198.cpp
// Purpose: Document similarity and compare (union and intersection) and remove ....
// Author(s): Abdelaziz Ali Ahmed Ali Elarabi
// ID(s): 20220198
// Section: s3-4
// Date: 12/10/2023

#include <iostream>
#include<fstream>
#include<vector>
#include <sstream>
#include<algorithm>
#include <cmath>



using namespace std;
string CleanWord(const string& word) {
    string cleanedWord;

    // Iterate through each character in the word
    for (char c : word) {
        // Check if the character is alphanumeric
        if (isalnum(c)) {
            // Convert the character to lowercase and add it to the cleanedWord
            cleanedWord += tolower(c);
        }
    }

    return cleanedWord;
}
class StringSet {
public:
    vector<string> v;

    StringSet(){};

    StringSet(const string &file_name) {
        ifstream input(file_name);
        string word;
        while (input >> word) {
            word = CleanWord(word);
            auto it = find(v.begin(), v.end(), word);
            if (it == v.end())
                v.push_back(word);
        }
        input.close();
    }

    StringSet(int diff, const string &tokens) {
        istringstream iss(tokens);
        string token;
        while (iss >> token) {
            token = CleanWord(token);
            auto it = find(v.begin(), v.end(), token);
            if (it == v.end())
                v.push_back(token);
        }

    }

    void addString(const string &s) {
        v.push_back(s);
    }

    void remove(const string &s) {
        auto it = find(v.begin(), v.end(), s);
        // Check if the string was found
        if (it != v.end()) {
            // Erase the element from the vector
            v.erase(it);
            std::cout << "Removed: " << s << std::endl;
        } else {
            std::cout << "String not found: " << s << std::endl;
        }
    }

    void Clear() {
        v.clear();
    }

    int size() const{
        return v.size();
    }

    void display() {
        for (auto c: v) cout << c << "\n";
    }

    // Overload + for union
    StringSet operator+(const StringSet &other)  {
        StringSet temp = *this;

        for (const auto &element: other.v) {
            auto it = find(temp.v.begin(), temp.v.end(), element);
            if (it == temp.v.end()) {
                temp.v.push_back(element);
            }
        }

        return temp;
    }
    // Overload * for intersection
    StringSet operator*(const StringSet& other)  {
        StringSet temp;

        // Iterate over the elements in 'other' and add them to the intersection set
        for (const auto& element : other.v) {
            auto it = find(v.begin(), v.end(), element);
            if (it != v.end()) {
                temp.v.push_back(element);
            }
        }

        return temp;
    }

    double similarity(const StringSet& other)  {
        StringSet intersectionSet = *this * other;

        double num =(double)(intersectionSet.size());
        double dem = sqrt(size()) * sqrt(other.size());

        return dem == 0.0 ? 0.0 : num / dem;
    }

};

int main() {
    // Create StringSet objects
    cout<<"Enter the file name: ";
    string file_name; cin>>file_name;

    StringSet set1(file_name);
    StringSet set2(2, "apple banana cherry");

    // Display the contents of the sets
    cout << "Set 1:\n";
    set1.display();

    cout << "\nSet 2:\n";
    set2.display();

    // Perform set operations
    StringSet unionSet = set1 + set2;
    StringSet intersectionSet = set1 * set2;

    // Display the union and intersection sets
    cout << "\nUnion Set:\n";
    unionSet.display();

    cout << "\nIntersection Set:\n";
    intersectionSet.display();

    // Calculate and display the similarity between sets
    double similarity = set1.similarity(set2);
    cout << "\nSimilarity between Set 1 and Set 2: " << similarity << endl;

    // Add a new string to Set 1
    set1.addString("orange");

    // Display the updated Set 1
    cout << "\nUpdated Set 1:\n";
    set1.display();

    // Remove a string from Set 2
    set2.remove("cherry");

    // Display the updated Set 2
    cout << "\nUpdated Set 2:\n";
    set2.display();

    return 0;
}