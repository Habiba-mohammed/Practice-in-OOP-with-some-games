// File name: A3_SheetPb1_20220106.cpp
// Purpose: solution for q1
// Author(s): Habiba mohamed ahmed
// ID(s): 20220106
// Section: s3/4
// Date: 9/12/2023


#include <string>
#include <fstream>
#include <iostream>
#include <iostream>
using namespace std;


class LabelGenerator {
private:
    string name;
    int point;

public:
    LabelGenerator(std::string name, int point);

    string nextlabel();
};

class FileLabelGenerator : public LabelGenerator {
private:
    string file_name;
    ifstream file;

public:
    FileLabelGenerator(string name, int point, string file_name);

    ~FileLabelGenerator();

    string nextlabel();
};


// Constructor
LabelGenerator::LabelGenerator(string name, int point) : name(name), point(point) {}

// Generate the next label
std::string LabelGenerator::nextlabel() {
    std::string label = name + to_string(point);
    point++;
    return label;
}

// Constructor
FileLabelGenerator::FileLabelGenerator(std::string name, int point, std::string file_name)
        : LabelGenerator(name, point), file_name(file_name) {
    file.open(file_name);
    if (!file.is_open()) {
        std::cerr << "Error opening the file" << endl;
    }
}

// Destructor
FileLabelGenerator::~FileLabelGenerator() {
    if (file.is_open()) {
        file.close();
    }
}

// Generate the next label with content from the file
string FileLabelGenerator::nextlabel() {
    string line;

    if (file.is_open() && getline(file, line)) {
        return LabelGenerator::nextlabel() + " " + line;
    } else {
        cerr << "Error reading from the file or file is not open" << endl;
        return "";
    }
}
int main() {
    LabelGenerator figureNumbers("Figure ", 1);
    LabelGenerator pointNumbers("P", 0);

    cout << "Figure numbers: ";
    for (int i = 0; i < 3; i++) {
        cout << figureNumbers.nextlabel() << ", ";
    }

    cout << endl << "Point numbers: ";
    for (int i = 0; i < 5; i++) {
        cout << pointNumbers.nextlabel() << ", ";
    }

    cout << endl << "More figures: ";
    for (int i = 0; i < 3; i++) {
        cout << figureNumbers.nextlabel() << ", ";
    }

    cout << endl;

    FileLabelGenerator figureLabels("Figure ", 1, "labels.txt");
    cout << "Figure labels: \n";
    for (int i = 0; i < 3; i++) {
        cout << figureLabels.nextlabel() << endl;
    }

    return 0;
}