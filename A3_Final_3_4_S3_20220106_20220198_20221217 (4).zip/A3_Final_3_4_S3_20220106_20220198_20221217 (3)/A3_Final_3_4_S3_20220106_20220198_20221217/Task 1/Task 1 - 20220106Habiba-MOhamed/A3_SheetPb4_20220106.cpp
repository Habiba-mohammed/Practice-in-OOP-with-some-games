// File name:q4
// Purpose:solution for q4
// Author(s): Habiba mohamed ahmed
// ID(s):20220106
// Section:s3/4
// Date:9/12/2023

#include <map>
#include <iostream>
using namespace std;
template <class T>
class Set
{
private:
    map<T, int> mp;

public:
    Set();

    bool isEmpty() const;

    int getSize() const;

    void insert(const T& item);

    void Delete(const T& item);

    bool Search(const T& item) ;

    void print() const;

    T* toArray() const;



};


class myFamily
{
private:
    int birthday;
    string name;

public:
    myFamily(int _birthday, const string& _name);

    int GetId() const;

    string GetName() const;

    bool operator==(const myFamily& other) const;

    bool operator!=(const myFamily& other) const;

    bool operator<(const myFamily& other) const;

    friend ostream& operator<<(ostream& out, const myFamily& state);
};

template <class T>
Set<T>::Set() {}

// Check if the set is empty
template <class T>
bool Set<T>::isEmpty() const
{
    return mp.empty();
}

// Get the size of the set
template <class T>
int Set<T>::getSize() const
{
    return mp.size();
}

// Insert an item into the set
template <class T>
void Set<T>::insert(const T& item)
{
    if (!Search(item))
        mp[item]++;
}

// Remove an item from the set
template <class T>
void Set<T>::Delete(const T& item)
{
    if (Search(item))
        mp.erase(item);
}

// Check if an item exists in the set
template <class T>
bool Set<T>::Search(const T &item)
{

    for (const auto& entry : mp)
    {
        if (entry.first == item )
        {
            return true;
        }
    }
    return false;

}

// Print the elements of the set
template <class T>
void Set<T>::print() const
{
    // might print the things with 0
    for (const auto& entry : mp)
    {
        cout << entry.first << " ";
    }
    cout << endl;
}
template <class T>
T* Set<T>::toArray() const
{
    int size = mp.size(); //size=3
    T* ptr = new T[size]; //[0,0,0] // pointer to array == dynamic array

    int index = 0;
    for (const auto& entry : mp)
    {
        ptr[index++] = entry.first;
    }

    return ptr;
}


template class Set<int>;  // Replace 'int' with the actual type(s) you plan to use


// Constructor
myFamily::myFamily(int _birthday, const std::string &_name) : birthday(_birthday), name(_name) {}

// Get the ID of the state
int myFamily::GetId() const
{
    return birthday;
}

// Get the name of the state
string myFamily::GetName() const
{
    return name;
}

// Equality operator
bool myFamily::operator==(const myFamily& other) const
{
    return (birthday == other.birthday) && (name == other.name);
}

// Inequality operator
bool myFamily::operator!=(const myFamily& other) const
{
    return (birthday != other.birthday) || (name != other.name);
}

// Less than operator
bool myFamily::operator<(const myFamily& other) const
{
    if (birthday != other.birthday) {
        return birthday < other.birthday;
    }
    //If birthdays are equal, compare names
    return name < other.name;
}
// Output stream operator
ostream& operator<<(ostream& out, const myFamily& state)
{
    out << "State ID: " << state.birthday << ", Name: " << state.name << '\n';
    return out;
}



int main()
{
    Set<myFamily> Family;
    myFamily Habiba(3, "Habiba"); //mp(1,START)=1
    myFamily Abdelaziz(4, "Abdelaziz");
    myFamily Diaa(9, "Diaa");
    myFamily Raheem(3, "Raheem");
    myFamily Royaa(4, "Royaa");



    Family.insert(Habiba);
    Family.insert(Abdelaziz);
    Family.insert(Diaa);
    Family.insert(Raheem);
    Family.insert(Royaa);




    cout << "Number of Members: " <<  Family.getSize() << "\n";
    cout << "Current Members: "<<'\n';
    Family.print();
    Family.Delete(Diaa);

    cout << "After removing 'Diaa': "<<'\n';
    Family.print();

    myFamily searchState(9, "Diaa");
    cout << "Does 'Diaa' exist? " << boolalpha << Family.Search(searchState) << "\n";
    Family.print();



    Set<int> mySet;

    // Insert elements into the set
    mySet.insert(1);
    mySet.insert(2);
    mySet.insert(1);
    mySet.insert(1);
    mySet.Delete(2);
    cout << "Set elements: "<<'\n';
    mySet.print();
    mySet.insert(11);
    mySet.insert(9);

    // Display set properties
    cout << "Set is empty: " << (mySet.isEmpty() ? "true" : "false") << endl;
    cout << "Set size: " << mySet.getSize() << endl;

    // Print elements of the set
    cout << "Set elements: ";
    mySet.print();

    Set<char> charSet;
    charSet.insert('a');
    charSet.insert('c');
    charSet.insert('d');
    charSet.print();


    Set<string> myset;

    // Insert elements into the set
    myset.insert("Habiba");
    myset.insert("Abdelaziz");
    myset.insert("Raheem");
    myset.insert("Royaa");
    myset.insert("Diaa");
    myset.Delete("Diaa");



    cout << "Set elements: "<<'\n';
    myset.print();
    // 1
// pointer + array( actions )
    // Use toArray to get a dynamically created array
    string* Ptr_array = myset.toArray(); // pointer to an array ( dynamic array )

    // Print elements of the array
    cout << "Array elements: ";
    for (int i = 0; i < myset.getSize(); ++i)
    {
        cout << Ptr_array[i] << " ";
    }
    cout << endl;

    // Don't forget to deallocate the memory
    delete[] Ptr_array;

    return 0;


}