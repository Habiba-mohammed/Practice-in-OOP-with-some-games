// File name: A3_SheetPb3_20221217.cpp
// Purpose: This program outputs a frequency table of
// words in a text file after removing all punctuation.
// Author: Mariam Amro Ahmed Fathi Seifeldin
// ID: 20221217
// Section: S3
// Last Modification Date: 6/12/2023

#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <iomanip>
#include <cstring>
#include <map>
#include <algorithm>
using namespace std;

int main(){
    map<string, int> frequency;
    cout << "Hello!\nPlease enter the name of your text file. (without .txt)\n";
    char fileName[100];
    cin >> fileName;
    strcat(fileName, ".txt");
    ifstream file(fileName);
    string input;
    string word = "";
    while(file >> input){
        for_each(input.cbegin(), input.cend(), [&word](char x){
            if (isalnum(x) || x == '-' || !(ispunct(x))){
                word += tolower(x);
            }
        });
        if (word != "-"  && word != ""){
            frequency[word]++;
        }
        word.clear();
    }
    cout << setw(11) << "Word" << setw(23)<< "Frequency" << "\n";
    cout << setw(50) << setfill('-') << "-" << setfill(' ')<< "\n";
    for (auto x : frequency) {
        int space = 20-(x.first.size());
        cout << x.first << setw(space) << ": " << setw(10) << x.second << "\n";
    }
    return 0;
}