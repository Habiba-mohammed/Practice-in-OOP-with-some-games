// Author: Mariam Amro Ahmed Fathi Seifeldin
// Last Modification Date: 6/12/2023
// ID: 20221217
// Section: S3


#include "Universe.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <fstream>
#include <cstring>
#include <string>
using namespace std;

Universe::Universe() {
    setSize();
    menu();
}

void Universe::initialise() {
    cout << "Would you like your Universe to be empty, randomly generated, initialised by coordinates in a file,";
    cout << " or initialised by given coordinates?\n" << flush;
    cout << "(Note: The coordinates read/entered will make a cell alive)\n" << flush;
    cout << "Press 0 for an empty Universe, 1 for a randomly generated one, 2 for reading a file,";
    cout << " or 3 for initialising your Universe.\n" << flush;
    int setting = 0;
    cin >> setting;
    if (setting == 1){
        randomUniverse();
    }else if (setting == 2){
        cout << "Enter the name of your text file. (without .txt)\n";
        char fileName[100];
        cin >> fileName;
        strcat(fileName, ".txt");
        readFile(fileName);
    }else if(setting == 3){
        cout << "Please insert the position of the cells you want alive.\n";
        int init = true;
        int i,j;
        while (init){
            cin >> i >> j;
            if ((i >= 0 && i < grid.size() )&& (j >= 0 && j < grid[0].size())){
                grid[i][j] = 1;
            }else{
                cout << "Sorry! Coordinates are out of range!\n" << flush;
            }
            cout << "Would you like to initialise more cells? Press 1 for yes, and 0 for no.\n" << flush;
            cin >> init;
            if (init != 0){
                init = 1;
            }
        }
        cout << flush;
        clearScreen();
        grid2 = grid;
        //display();
    }else{
        reset();
    }
    clearScreen();
    cout << " Below is your Universe.\n" << flush;
    display();

}

void Universe::reset() {
    for (int i = 0; i < grid.size(); ++i) {
        for (int j = 0; j < grid[i].size(); ++j) {
            grid[i][j] = false;
        }
    }
}

void Universe::next_generation() {
    grid2 = grid;
    for (int i = 0; i < grid.size(); ++i) {
        for (int j = 0; j < grid[i].size(); ++j) {
            int neighbors = count_neighbors(i, j);
            if (neighbors < 2){
                grid[i][j] = 0;
            }else if (neighbors > 3){
                grid[i][j] = 0;
            }else if (neighbors == 3){
                grid[i][j] = 1;
            }
        }
    }
    clearScreen();
    display();
}

void Universe::display() {
    cout << "\n" << setw(10) <<"rows: " << flush;;
    for (int i = 0; i < columns; ++i) {
        cout << setw(2) << i << " " << flush;;
    }
    cout << "\n\n" << flush;
    for (int i = 0; i < grid.size(); ++i) {
        cout << setw(7) <<  i << ":  " << flush;
        for (int j = 0; j < grid[i].size(); ++j) {
            cout << setw(2) << grid[i][j] << " " << flush;
        }
        cout << "\n";
    }
    cout << flush;
    clearScreen();
}

int Universe::count_neighbors(int i, int j) {
    int neighbors = 0;
    int i_index[3] = {-1, 0, 1};
    int j_index[3] = {-1, 0, 1};
    for(int k = 0; k < 3; ++k) {
        for(int l = 0; l < 3; ++l) {
            if (((i+i_index[k]) >= 0 && (i+i_index[k]) < grid.size())){
                if (((j+j_index[l]) >= 0 && (j+j_index[l]) < grid[i].size())){
                    if (i_index[k] == 0 && j_index[l] == 0){
                    }else{
                        neighbors += grid2[i+i_index[k]][j+j_index[l]];
                    }
                }
            }
        }
    }

    return neighbors;
}

void Universe::run(int n) {
    while (n--){
        next_generation();
    }
}

void Universe::clearScreen() {
    cout << flush;
    system ("PAUSE");
    #ifdef _WIN32
        system("cls");
        system("cls");
    #else
        system("clear");
        system("clear");
    #endif
}

void Universe::menu() {
    initialise();
    bool exit = false;
    int option;
    while (!exit){
        cout << "What would you like to do?\n";
        cout << "1. Initialise some cells.\n";
        cout << "2. View the next generation.\n";
        cout << "3. View n generations.\n";
        cout << "4. View your Universe.\n";
        cout << "5. Reset your Universe.\n";
        cout << "6. Clear your screen.\n";
        cout << "7. Generate a new random Universe.\n";
        cout << "8. Exit.\n";
        cin >> option;
        switch (option) {
            case 1:
                initialise();
                break;

            case 2:
                next_generation();
                break;

            case 3:
                int n;
                cout << "Please enter the number of generations you would like to run.\n";
                cin >> n;
                run(n);
                break;

            case 4:
                clearScreen();
                display();
                break;

            case 5:
                reset();
                break;

            case 6:
                clearScreen();
                break;

            case 7:
                clearScreen();
                randomUniverse();
                display();
                break;

            case 8:
                cout << "Goodbye!\n" << flush;
                exit = true;
                break;

            default:
                break;
        }
        clearScreen();
    }

}

void Universe::randomUniverse() {
    srand(time(0));
    for (int i = 0; i < grid.size(); ++i) {
        for (int j = 0; j <grid[i].size() ; ++j) {
            int random = rand();
            grid[i][j] = random % 2;
        }
    }
}

void Universe::readFile(string file) {
    ifstream Info (file);
    char in;
    int count = 0;
    int coordinate;
    int i = 0;
    int j = 0;
    while (Info >> in){
        if (isdigit(in)){
            coordinate = in - '0';
            if (!count){
                i = coordinate;
            }else{
                j = coordinate;
                if ((i >= 0 && i < grid.size() )&& (j >= 0 && j < grid[0].size()))
                    grid[i][j] = 1;
            }
            count = (++count) % 2;
        }
    }
}

void Universe::setSize() {
    /*int rows, columns;
    rows = columns = 0;*/
    cout << "Hello! Welcome to the our simulation of the Game of Life!\n" << flush;
    cout << "Please enter the size you would like your Universe to be.\n";
    cin >> rows >> columns;
    cout << "The size of your Universe is "<< rows << "x" << columns << ".\n" << flush;
    grid.resize(rows, std::vector<bool>(columns, false));
    clearScreen();

}


