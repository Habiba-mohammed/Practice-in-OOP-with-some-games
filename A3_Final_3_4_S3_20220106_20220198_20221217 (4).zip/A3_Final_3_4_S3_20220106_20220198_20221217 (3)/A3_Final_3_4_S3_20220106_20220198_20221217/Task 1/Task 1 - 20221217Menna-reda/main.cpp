// Author: Mariam Amro Ahmed Fathi Seifeldin
// Last Modification Date: 6/12/2023
// ID: 20221217
// Section: S3

#include "Universe.h"

using namespace std;

int main(){
    Universe uni;
    return 0;
}
