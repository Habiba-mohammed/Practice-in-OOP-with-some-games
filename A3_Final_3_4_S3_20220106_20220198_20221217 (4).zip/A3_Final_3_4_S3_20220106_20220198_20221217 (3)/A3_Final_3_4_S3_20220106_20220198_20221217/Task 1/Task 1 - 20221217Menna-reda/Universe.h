// Author: Mariam Amro Ahmed Fathi Seifeldin
// Last Modification Date: 6/12/2023
// ID: 20221217
// Section: S3


#ifndef CS213_A3_OBJECT_ORIENTED_PROGRAMMING_UNIVERSE_H
#define CS213_A3_OBJECT_ORIENTED_PROGRAMMING_UNIVERSE_H
#include <iostream>
#include <vector>
using namespace std;

class Universe {
private:
    int rows = 0;
    int columns = 0;
    vector<vector<bool>> grid;
    vector<vector<bool>> grid2;
    void initialise();
    int count_neighbors(int i, int j);
public:
    Universe();
    void reset();
    void next_generation();
    void display();
    void run(int n);
    void clearScreen();
    void menu();
    void randomUniverse();
    void readFile(string file);
    void setSize();
};


#endif //CS213_A3_OBJECT_ORIENTED_PROGRAMMING_UNIVERSE_H
